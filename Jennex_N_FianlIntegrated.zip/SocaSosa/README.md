# SocaSosa! Everything Music

# All about the tunes! This is a fan website dedicated to the Hip-Hop community.

## Requirements 
You will end a working up-to-date internet browser.

you'll also need git installed locally, as well as a preprocessor like SASS. A good code editor helps too!

## Built With:
1. Markdown

## Installation
CD to the location of your choice, ad then do   git clone. Code away!!

## License
MIT

## Authors
1. NJ - Graphic Designer
2. NJ - Front-End Dev
```


